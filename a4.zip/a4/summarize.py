"""
sumarize.py
"""
