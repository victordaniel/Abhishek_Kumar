See a2.py.
